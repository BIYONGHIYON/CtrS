import sys, json, numpy as np, torch
sys.path.insert(0, r'C:\CtrS-ssai11')
import phase0 as P
from common.model import RestoredPansharpeningNet
P.suite.configure(42, 'cuda')
va = P.suite.Cached(P.CACHE)
pan, lms, ms, gt = (torch.from_numpy(np.array(va.arrays[k])) for k in ('pan', 'lms', 'ms', 'gt'))
a0 = RestoredPansharpeningNet(4, 4); a0.load_state_dict(torch.load(P.A0, map_location='cpu', weights_only=False)['model']); a0.cuda().eval()
err = (gt - P.predict(a0, pan, lms, ms)).cuda()
perm = torch.roll(torch.arange(len(pan)), 1)  # PAN of a different patch: same statistics, unrelated content
out = {}
for kind in ('S1', 'S2'):
    B = torch.cat([P.bases(pan[perm][i:i+256].cuda(), kind) for i in range(0, len(pan), 256)])
    for c in (4, 8, 16, 64):
        out[f'{kind}_cell{c}'] = P.oracle_explained(err, B, c)
print(json.dumps(out))
json.dump(out, open(r'C:\CtrS-ssai11\runtime\phase0_null.json', 'w'), indent=2)
