# 5. softmax와 sigmoid 혼합 게이트

**연구 분야:** ssai · **실험자:** 이병현 · **상태:** 준비 · **개선 여부:** 판단 보류

## 1. 목적과 상태
실험4의 sigmoid는 FR 향상과 RR 악화를 보였습니다. 원본의 공간 경쟁을 일부 유지하면 손실을 줄일 수 있다는 가설을 검증합니다. M25·M50만 새로 학습합니다.

## 2. 변경한 구조와 비교 조건
PAN과 MS 특징을 기존 convolution으로 K=4 특징 P·Q로 변환합니다. 원본의 두 전치·reshape를 그대로 유지해 Z를 만들고 W=(1−α)softmax(Z)+α(2/A_ref)sigmoid(Z), 출력=P×W로 변경합니다. 기준 면적은4096·1024·256입니다. 출력은 기존 밴드 융합·단일복원으로 전달합니다. 추가 파라미터는0입니다. K4와 공간4배확대는 별개이며 backbone·복원·MSE·데이터처리는 동일합니다.

```mermaid
flowchart LR
 P[PAN의 기존 K채널 특징] --> Z[원본 전치와 MS 특징의 곱]
 Q[MS의 기존 K채널 특징] --> Z
 Z --> S[공간 softmax]
 Z --> G[기준 크기 sigmoid]
 S --> W[고정 비율 혼합]
 G --> W
 P --> O[P 곱하기 혼합 가중치]
 W --> O
 O --> R[기존 융합과 복원]
```

M25 α=.25·M50 α=.50, QB seed42·100에폭·micro/effective32·FP32·Adam lr1e-4·동일 샘플순서·새 초기값입니다. A0 α=0·A2 α=1은 [실험4](../4_aligned_sigmoid_gating/README.md)의 실제 결과를 참조하며 복제학습하지 않습니다. 재사용 전 환경·원본 데이터·캐시·기준코드·체크포인트 설정/해시를 검증합니다.

## 3. 정량 결과
아직 없습니다. checkpoint와 비율은 validation MSE로 선택하고 정확한 동률은 최초 epoch를 선택합니다. A0 기준 .0001715509279241805를 사용합니다. test로 후보·계수를 선택하지 않습니다.

## 4. 장면별 비교
학습 후 RR·FR 장면별 차이를 보고합니다. FR에는 GT가 없습니다. 재사용 test는 탐색용이며 독립 holdout이 아닙니다.

## 5. 비용과 실행
같은 서버 최대2개 병렬·GPU cache·micro32를 유지합니다. 실제 두 후보의 train/validation/atomic save-reload 병렬 probe가 여유512MiB를 통과해야 실행합니다. 측정된 worker budget에192MiB를 더해 시작 시 검사합니다. 실행 중 자동 배치 축소나 연속 VRAM 감시는 없습니다. 두 게이트의 추가연산 비용은 평가 때 측정합니다.

## 6. 재현과 보존
run.py로 새 runtime을 준비하고 common/ssai_suite.py benchmark, start로 SSH와 독립적인 WMI controller를 시작합니다. runtime은 C:/CtrS-ssai5/runtime/qb_s42_100입니다. 기존 cache는 읽기 전용 참조이며 기존 runtime을 변경하지 않습니다. 실제 소스·설정·optimizer/RNG와 best/latest를 보존합니다.

## 7. 결론과 한계
개선 미확인입니다. 단일센서·시드이며 QNR의 MATLAB parity는 미검증입니다. 같은 서버 사용만으로 동일조건을 보장하지 않습니다.

## 8. 남은 일
100에폭 완료, validation 비교, RR/FR·장면별·비용 평가 및 실제 가중치 원격 보존이 남았습니다. validation 통과 후보만 반복시드·센서확장을 제안하며 자동실행하지 않습니다.
