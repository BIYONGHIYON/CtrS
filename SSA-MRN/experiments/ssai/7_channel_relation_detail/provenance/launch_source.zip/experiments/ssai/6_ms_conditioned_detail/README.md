# 6. MS 조건부 공간 세부정보 보정

**연구 분야:** ssai · **실험자:** 이병현 · **상태:** 준비 · **개선 여부:** 판단 보류

## 1. 목적과 상태
원본 SSAI 출력을 유지하며 MS가 선택한 PAN 공간 세부정보를 잔차로 보정합니다. D6만 신규 학습하고 실험4 A0 대조군을 재사용합니다. 다른 가설은 별도 폴더입니다.

## 2. 변경한 구조와 비교 조건
기존 PAN convolution이 만드는 K채널 P와 MS convolution이 만드는 Q, 원본 좌표·spatial softmax의 출력Y0을 유지합니다. H(x)=x−3×3주변평균(reflect 경계), D=H(P), G=2sigmoid(Q)입니다. 출력은 Y0+H(Wout(G×D))/Aref입니다. Wout은4→4 1×1 convolution·bias없음·0초기화입니다. 원본 초기 파라미터와 RNG를 유지하여 초기 전체 출력은 원본과 같고, 마지막 convolution의 gradient는 학습을 시작할 수 있습니다.

6번은 D를 채널 관계행렬로 혼합하지 않습니다. 7번과 추가 파라미터는 같고 관계 연산만 다릅니다.

입력 PAN N×1×H×W와 MS특징·해당밴드 N×(C+1)×H×W, 출력 N×K×H×W를 유지하며 연결부 변경은 없습니다. K4·공간4배확대·backbone·단일복원·MSE·데이터처리는 동일합니다. Aref4096·1024·256고정, 새 파라미터192개, 총426846개입니다. 고주파 제한은 분광보존을 보장하지 않습니다.

```mermaid
flowchart LR
 PAN[PAN] --> P[기존 PAN 특징 P]
 MS[MS 특징] --> Q[기존 MS 특징 Q]
 P --> O[원본 SSAI 출력]
 Q --> O
 P --> D[주변 평균 제거]
 Q --> G[MS sigmoid 게이트]
 D --> C[세부정보 선택과 보정]
 G --> C
 C --> W[0초기화 convolution과 주변 평균 제거]
 W --> Y[원본 출력에 더함]
 O --> Y
 Y --> R[기존 융합과 복원]
```

QB seed42·100에폭·처음부터micro/effective32·FP32·Adam lr1e-4·동일 샘플순서·새 초기값입니다. 7번만4×4채널관계가 추가됩니다. 같은 환경·원본 H5·cache·기준코드·가중치 설정/해시를 확인하고 캐시와 A0를 참조합니다.

## 3. 정량 결과
아직 없습니다. minimum validation MSE·최초동률epoch로 checkpoint선택, 기준 .0001715509279241805입니다. test로 후보·온도·형상을 선택하지 않습니다. RR PSNR+.2dB는 목표이며 예상 향상치가 아닙니다.

## 4. 장면별 비교
완료 후 RR·FR각20전체장면의 지표·장면별차이·사전고정 예시를 평가합니다. FR에는 GT가 없습니다. 기존 test는 탐색에 사용돼 독립holdout이 아닙니다.

## 5. 비용과 실행
두 후보를 같은 서버에서 최대2개 병렬 실행합니다. GPU cache·micro32·FP32를 유지하고 actual train/validation/atomic save-reload probe가 여유512MiB를 통과해야 시작합니다. 실행 중 자동 배치변경·driver hang 복구는 없습니다. 7번 관계행렬은4×4이며 연산 O(K²HW), 공간HW×HW행렬은 만들지 않습니다. 총 MAC·지연시간·VRAM은 실측해야 합니다.

## 6. 재현과 보존
common/ssai_detail.py는6·7이 실제 공유하는 보정 코드이고 common/ssai_detail_prepare.py는 같은 suite의 검증·준비 도구입니다. source C:/CtrS-ssai-detail/SSA-MRN, runtime C:/CtrS-ssai-detail/runtime/qb_s42_100입니다. 준비·benchmark·WMI detached start를 사용합니다. 원본source/plan, optimizer/RNG, best/latest를 보존합니다. 이전 runtime과 cache를 삭제·덮어쓰기하지 않습니다.

## 7. 결론과 한계
개선 미확인입니다. 단일QB seed42·100에폭이며 metric MATLAB parity가 미검증입니다. 기존 초기출력 유지와작은 추가용량이 개선을 보장하지 않습니다. 두 후보 모두 동일192개 추가파라미터로 구조비교하며 A0와는 용량 차이가 있습니다.

## 8. 남은 일
정상 학습·최종 validation·RR/FR·비용·장면별 비교·실제 가중치 원격 보관이 남았습니다. 반복시드·센서확장은 결과 후 결정하고 자동실행하지 않습니다.
