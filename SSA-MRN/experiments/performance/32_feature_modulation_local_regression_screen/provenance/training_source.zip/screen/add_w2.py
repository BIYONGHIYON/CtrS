"""Start W2 (gate failed; run as confirmation per user request) once the second pair has started."""
import os, sys, time, subprocess
HERE = os.path.dirname(os.path.abspath(__file__)); RT = sys.argv[1]
while not os.path.exists(os.path.join(RT, 'W1c', 'status.json')):
    if os.path.exists(os.path.join(RT, 'stop.request')): sys.exit(0)
    time.sleep(10)
time.sleep(60)
with open(os.path.join(RT, 'queue.log'), 'a') as f: f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + 'started W2 (user-requested confirmation despite failed gate)\n')
with open(os.path.join(RT, 'W2.log'), 'w') as f:
    r = subprocess.run([sys.executable, os.path.join(HERE, 'train.py'), '--arm', 'W2', '--a0', r'C:\CtrS-ssai4\runtime\qb_s42_100\A0\best.pt', '--cache', r'C:\CtrS-ssai4\runtime\qb_s42_100\cache', '--runtime', RT, '--diag', os.path.join(RT, 'diag.json')], stdout=f, stderr=subprocess.STDOUT)
with open(os.path.join(RT, 'queue.log'), 'a') as f: f.write(time.strftime('%Y-%m-%d %H:%M:%S ') + f'W2 exit {r.returncode}\n')
