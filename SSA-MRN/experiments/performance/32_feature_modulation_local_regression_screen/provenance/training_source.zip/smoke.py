import os, sys, time
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
sys.path.insert(0, r'C:\CtrS-h1h2\SSA-MRN')
import torch
from common import ssai_suite as suite
from common.model import RestoredPansharpeningNet
from screen.model import ScreenNet
ck = torch.load(r'C:\CtrS-ssai4\runtime\qb_s42_100\A0\best.pt', map_location='cpu', weights_only=False)
g = torch.Generator(device='cuda').manual_seed(0)
x = [torch.rand(32, c, s, s, device='cuda', generator=g) for c, s in ((1, 64), (4, 64), (4, 16), (4, 64))]
suite.configure(42, 'cuda'); ref = RestoredPansharpeningNet(4, 4); ref.load_state_dict(ck['model']); ref.cuda().eval()
with torch.no_grad(): r0 = ref(*x[:3])
for arm in ('W0', 'W1', 'W1c', 'W2'):
    suite.configure(42, 'cuda'); m = ScreenNet(arm, 1e-4); miss, unexp = m.load_state_dict(ck['model'], strict=False); m.cuda()
    with torch.no_grad(): d = float((m.eval()(*x[:3]) - r0).abs().max())
    m.train(); opt = torch.optim.Adam(m.parameters(), 1e-4)
    for i in range(8):
        if i == 3: torch.cuda.synchronize(); t = time.perf_counter()
        opt.zero_grad(); torch.nn.functional.mse_loss(m(*x[:3]), x[3]).backward(); opt.step()
    torch.cuda.synchronize()
    print(arm, 'new', sum(p.numel() for n, p in m.named_parameters() if n in miss), 'unexpected', len(unexp), 'start_diff', d, 'step_ms %.1f' % ((time.perf_counter() - t) / 5 * 1000), flush=True)
